package com.example.anination05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Anination05Application {

	public static void main(String[] args) {
		SpringApplication.run(Anination05Application.class, args);
	}

}
