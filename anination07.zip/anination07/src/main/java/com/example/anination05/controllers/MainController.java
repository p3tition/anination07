package com.example.anination05.controllers;

import com.example.anination05.models.User;
import com.example.anination05.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/user_example")
    public String home(Model model){
        return "home";
    }

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/users")
    public String users(Model model){
        Iterable<User> users = userRepository.findAll();
        for (User user : users) {
            user.encodePhoto(); // Call the encodePhoto method to set the base64EncodedImage property
        }
        model.addAttribute("users",users);
        return "users";
    }

}