package com.example.anination05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Anination05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
